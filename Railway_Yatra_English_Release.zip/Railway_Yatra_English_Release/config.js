/* Supabase client configuration. Never put a secret/service_role key here. */
window.RAILWAY_YATRA_CONFIG = {
  supabaseUrl: "https://zisrzwlnwamtfedutxst.supabase.co",
  supabaseKey: "sb_publishable_X5EgA6mHUTqxu1uAAEQXcA_YS_SPz2n"
};
